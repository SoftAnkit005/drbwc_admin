import React from 'react';
import '../../assets/scss/style.scss';

const LightTheme = () => {
  return <></>;
};

export default LightTheme;
